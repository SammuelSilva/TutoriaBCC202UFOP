//É importante ressaltar que nas suas funções adaptadas desta, não deverá ter "cin"
//dentro das TADS

#include "produto.hpp"

//Definição da struct Produto
struct Produto{
  int preco;
  int quantidadeTotal; //Quantidade Total do produto encontrada na loja
  int quantidadeVendida;//Quantidade vendida desse produto
  string tipo; //Tipo do produto: Alimenticio, limpeza ...
  string nome; //Nome do produto
};

//Aloca os espaços da memoria necessario para o vetor de produto e aloca os
//"indices" do vetor.
Produto** setProd(int qnt){
  Produto** produto = new Produto*[qnt]; //Alocacao do espaco da memoria necessario
  for(int i=0; i<qnt; i++){
    produto[i]= new Produto; //Alocacao dos "indices"
  }

  return produto; //retorna um ponteiro de ponteiro do tipo produto devidamente alocado
}

//Inserção de dados em uma posicao do vetor de produtos
//[ RETIRE OS CIN, OS DADOS DEVEM VIR DA MAIN]
void putProd(Produto *produto){
  cout << "Preco: ";
  cin >> produto->preco;
  cout << "quantidade Total: ";
  cin >> produto->quantidadeTotal;
  produto->quantidadeVendida=0;
  cout << "Tipo do produto: ";
  cin >> produto->tipo;
  cout << "Nome do produto: ";
  cin >> produto->nome;
}

//Remocao de um produto. Caso ele seja encontrado é rearranjado o vetor e retorna true
//caso contrario retorna false
bool removeProd(Produto **prod, string aux, int qnt){
  int i=0;
  while(i<qnt){
    if(prod[i]->nome==aux){
     for(int j=i; j<qnt-1;j++){ //Comeca a sobrescrever a partir da posicao que desejamos remover
       prod[i]=prod[i+1];
     }
     return true;
   }
  }
  return false;
}

//Funcao que retorna o nome de um produto
string getProd(Produto *prod){
  return prod->nome;
}

//Funcao que deleta um indice do vetor de produtos
void deletar(Produto *prod){
  delete prod;
}
