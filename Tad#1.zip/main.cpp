#include <iostream>
#include "loja.hpp"
using namespace std;

int main(){
  Loja *loja;
  int op;

  //Aloca na memoria a loja e o ponteiro de ponteiro de produto
  loja = set();
  setLoja(loja);

  do {
    cout << "Opcao [ 1. Inserção de Produto | 2. Remocao de Produto | 3. Impressao | 4. Nova Loja]" << endl << "Op: ";
    cin >> op;
    switch (op) {
      case 1: //Insere um produto na loja
        put(loja);
        break;
      case 2: //Remove um produto da loja
        remover(loja);
        break;
      case 3: //Imprime os produtos da loja
        imprime(loja);
        break;
      case 5: //Deleta totalmente uma loja e cria uma nova do zero
        deletar(loja);
        setLoja(loja);
        break;
    }
  } while(op!=0); //Laco realizado ate op == 0

  deletar(loja); //deleta totalmente uma loja
  return 0;
}
