#ifndef LOJA_HPP
#define LOJA_HPP

#include <iostream>
#include <cstring>
#include "produto.hpp"
using namespace std;

typedef struct Loja loja;
void setLoja(Loja *loja);
loja* set();
void imprime(Loja *loja);
void put(Loja *loja);
void remover(Loja *loja);
void deletar(Loja* loja);

#endif
