//É importante ressaltar que nas suas funções adaptadas desta, não deverá ter "cin"
//dentro das TADS
#include "loja.hpp"

//Declaração da Struct de Loja
struct Loja{
  string nome;
  Produto **produto; //Nosso vetor de produtos
  int quantidadeTotal; //Quantidade total do vetor de produtos
  int quantidade; //Quantidade Alocada no vetor de produtos
};

//Alocar uma loja usando um auxiliar
loja* set(){
  Loja* auxiliar = new Loja;
  return auxiliar;
}

//Inicializar os valores da loja e o ponteiro de ponteiro de produtos
//[ RETIRE OS CIN, OS DADOS DEVEM VIR DA MAIN]
void setLoja(Loja *loja){
  cout << "Digite o Nome da loja: ";
  cin >> loja->nome;
  cout << "Digite a quantidade de produtos: ";
  cin >> loja->quantidadeTotal;
  loja->quantidade=0;
  loja->produto=setProd(loja->quantidadeTotal); //Alocação do vetor de produtos passando
                                                // a quantidade total alocada
}

//Imprime todos os produtos do vetor. Como estou passando o produto com um indice
//usaremos ele na TAD Produto como um ponteiro.
void imprime(Loja *loja){
  for(int i=0; i<loja->quantidade; i++){
    cout <<"Produto: " << getProd(loja->produto[i]) << endl;
  }
}

//Insersão de dados no vetor de produtos, para isso precisamos criar uma
//função em Loja para chamar a função em putProd(variaveis)
void put(Loja *loja){
  if(loja->quantidade < loja->quantidadeTotal){ //Verificação de espaco para a inserção de dados
    putProd(loja->produto[loja->quantidade]); //Insersao de dados em produtos
    loja->quantidade++; //Incrementa o contador de produtos presentes no vetor
  }else{
    cout << "Sem espaços" << endl;
  }
}

//Função para remover um produto contido no vetor de produto
//[ RETIRE OS CIN, OS DADOS DEVEM VIR DA MAIN]
void remover(Loja *loja){
  string aux;
  cout << "Digite o produto que deseja retirar" << endl;
  cin >> aux;

  if(removeProd(loja->produto, aux, loja->quantidade)){ //Chama a função de remover produto da TAD Produto
    cout << "Produto Removido" << endl;
    loja->quantidade--; //Se removido decrementamos o valor do nosso contador de produtos alocados
  }else cout << "Produto nao encontrado" << endl;
}

//Deletar os "indices" do vetor de produtos atraves de uma função que recebe um ponteiro de produto.
//Depois deletamos os espacos reservados na memoria para o vetor de produtos e a loja.
void deletar(Loja* loja){
  for(int i=0; i<loja->quantidadeTotal; i++){
    deletar(loja->produto[i]);
  }
  delete[] loja->produto;
  delete loja;
}
