#ifndef PRODUTO_HPP
#define PRODUTO_HPP

#include <iostream>
#include <cstring>

using namespace std;

typedef struct Produto produto;

Produto** setProd(int qnt);
void putProd(Produto *produto);
bool removeProd(Produto **prod, string aux, int qnt);
string getProd(Produto *prod);
void deletar(Produto *prod);

#endif
