//Revisão Ponteiros and basic stuff

#include <iostream>
#include <string.h>

using namespace std;

void swap(char* ptr, char aux){
  char mem = *(ptr+3);
  *(ptr+3)=aux;
  *ptr=mem;
}

int main(){
  char *ptr = new char[12];

  cin >> ptr;
  swap(ptr, *ptr);
  swap(++ptr, *(ptr+1));
  ptr--;
  cout << ptr << endl;

  delete []ptr;
}
