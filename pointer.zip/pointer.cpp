//Revisão Ponteiros and basic stuff

#include <iostream>
#include <string.h>

using namespace std;


int main(){
  char str[]="The Dark Side of The Moon";
  char *ptr = str;

  cout << str[0] << " " << *ptr << " " << ptr[7] << "\n";
  ptr+=17;
  for(int i=17; i<(int)strlen(str); i++){
    cout << *ptr;
    ptr++;
  }
  ptr = str;
  cout << "\n" << ptr << endl;
}
