//Revisão Ponteiros and basic stuff

#include <iostream>
#include <string.h>

using namespace std;

int main(){
  int tamanho, i=0, j=0;
  cin >> tamanho;
  int **ptr = new int*[tamanho];

  for(i=0; i<tamanho; i++){
    ptr[i]= new int;
  }

  for(i=0; i<tamanho; i++){
    for(j=0; j<tamanho; j++){
      cin >> ptr[i][j];
    }
  }

  for(j=0; j<tamanho; j++){
    for(i=0; i<tamanho; i++){
      cout << ptr[i][j] << " ";
    }
    cout << endl;
  }

  for(j=0; j<tamanho; j++){
    delete[] ptr[j];
  }

  delete[] ptr;
}
