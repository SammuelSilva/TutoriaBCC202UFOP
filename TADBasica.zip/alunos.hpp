#ifndef ALUNOS_HPP
#define ALUNOS_HPP

#include <iostream>
#include <cstring>

using namespace std;

typedef struct Alunos alunos;

Alunos** criar(int quantidade);
bool update(Alunos** alunos, int& posicao, int quantidade, string nome, string matricula);
bool remover(Alunos** alunos, string matricula, int quantidade);
void imprime(Alunos** alunos, int quantidadeCadastrada);
void deletar(Alunos** alunos, int quantidade);


#endif
