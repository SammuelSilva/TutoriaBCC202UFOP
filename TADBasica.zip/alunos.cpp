#include <iostream>
#include <cstring>

using namespace std;

//Definição da struct alunos
struct Alunos{
  string matricula;
  string Nome;
};

//Função responsavel por inicializar o ponteiro de ponteiro, que retorna um ponteiro de ponteiros
//devidamente alocado
Alunos** criar(int quantidade){
  Alunos** alunos = new Alunos*[quantidade];
  for(int i=0; i<quantidade; i++){
    alunos[i]= new Alunos;
  }

  return alunos;
}

//Insere alunos se tiver espaço no vetor
bool update(Alunos** alunos, int& posicao, int quantidade, string nome, string matricula){
  if(posicao<quantidade){
    alunos[posicao]->Nome = nome;
    alunos[posicao]->matricula = matricula;
    posicao++;
    return true;
  }

  return false;
}

//Remove o aluno se este for encontrado no vetor
bool remover(Alunos** alunos, string matricula, int quantidade){
  int i=0;
  while((alunos[i]->matricula != matricula) && (i<quantidade)) i++;
  if(i<quantidade){
    for(int j=i; j<quantidade-1; j++){
      alunos[j]=alunos[j+1];
    }
    return true;
  }

  return false;
}

//Imprime todos os alunos e suas matriculas
void imprime(Alunos** alunos, int quantidadeCadastrada){
  for(int i=0;i<quantidadeCadastrada; i++){
    cout << endl;
    cout << "Nome: " << alunos[i]->Nome;
    cout << "\nMatricula: " << alunos[i]->matricula << endl;
  }
  cout << endl;
}

//Deleta os ponteiros, do mais interno para o mais externo, além de verificar se a posição
//foi alocada.
void deletar(Alunos** alunos, int quantidade){
  for(int i=0; i<quantidade; i++){
    if(alunos[i]!=NULL) delete alunos[i];
    else cout << "Endereço nulo" << endl;
  }

  delete[] alunos;
}
