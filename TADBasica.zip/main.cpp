#include <iostream>
#include <cstring>
#include "alunos.hpp"
using namespace std;

int main(){
  Alunos** alunos;
  int op, quantidade;
  string nome, matricula;

  cout << "Entre com a quantidade de alunos: ";
  cin >> quantidade;

  alunos=criar(quantidade); //Aloca o vetor de ponteiro;

  int posicao=0; //Quantidade de alunos cadastrados = 0;

  do {
    cout << "Opcao ";
    cin >> op; //Usuario entra com uma opçao
    switch (op) {
      case 1: //Cadastra um aluno
        cout << "Digite o Nome e a Matricula: ";
        cin >> nome >> matricula;
        if(update(alunos,posicao,quantidade,nome,matricula)) cout << "Inserção Completa\n";
        else cout << "Falha na Inserção" << endl;
        break;
      case 2: //Remove um aluno
        cout << "Digite a Matricula que deseja remover: ";
        cin >> matricula;
        if(remover(alunos, matricula, posicao)){
          cout << "Remoção completa" << endl;
          posicao--; //Decrementa a quantidade de alunos cadastrados
        }else cout << "Falha na Remoção" << endl;
        break;
      case 3: //Imprime todos alunos cadastrados
        imprime(alunos, posicao);
        break;
    }
  } while(op!=0);

  deletar(alunos, quantidade); //Deleta os ponteiros
  return 0;
}
